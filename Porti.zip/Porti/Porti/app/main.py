from flask import Flask,url_for,render_template

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/sobre-mim')
def perfil():
    return render_template('sobre-mim.html')

@app.route('/hobbies')
def perfil_hobbies():
    return render_template('sobre-hobbies.html')

@app.route('/contatos')
def perfil_contatos():
    return render_template('sobre-contatos.html')

@app.route('/novidades')
def novidades():
    return render_template('novidades.html')

if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0")
